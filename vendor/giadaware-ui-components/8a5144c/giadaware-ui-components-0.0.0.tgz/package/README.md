# giadaware-ui-components

Private-incubation Svelte components for GiadaWare.

This is a public GitHub repository containing a package whose manifest uses
`private: true`.

That flag prevents registry publication. It does not make the GitHub
repository private.

During the trial, immutable package artifacts are created with `npm pack`,
identified by source commit, filename and checksum, and installed only in
controlled consumers.

No npm account, organization, scope, registry identity or publication workflow
is required.

Atelier-Kit is the first validation consumer. It is not a dependency of this
package.

The approved trial contains:

- `SocialIcon`
- `FormStatus`
- `ImageAttachmentControl`
- `AsyncOperationPanel`
- `Button`
- `PageIntro`
- `FieldLabel`
- `FormActions`
- `Panel`
- `Surface`

The three JavaScript entry graphs remain isolated. Their current public APIs
are:

- `giadaware-ui-components` exports `FormStatus`, `FormStatusTone`,
  `SocialIcon`, `SocialIconId` and `SOCIAL_ICON_IDS`;
- `giadaware-ui-components/visitor` exports `RelationshipGraph` and its public types;
- `giadaware-ui-components/studio` exports `ImageAttachmentControl` and the
  `ImageAttachmentControlLabels`, `ImageAttachmentCurrentImage`,
  `ImageAttachmentFileValidator`, `ImageAttachmentIntent`,
  `ImageAttachmentState` and `ImageAttachmentValidationError` types, plus
  `AsyncOperationPanel` and its public types, plus `Button`, `ButtonProps`,
  `ButtonVariant` and `ButtonSize`, plus `PageIntro` and `PageIntroProps`, plus
  `FieldLabel` and `FieldLabelProps`, plus `FormActions`, `FormActionsProps`
  and `FormActionsAlign`, plus `Panel`,
  `PanelProps` and `PanelHeadingLevel`, plus `Surface` and `SurfaceProps`.

See [AsyncOperationPanel](docs/async-operation-panel.md) for its state model,
snippet contract, accessibility behavior, examples, and styling hooks.

See [Button](docs/button.md) for native attribute forwarding, variants, sizes,
accessibility responsibilities, examples, and CSS custom properties.

See [PageIntro](docs/page-intro.md) for its paragraph and snippet contract,
responsibility boundary, accessibility behavior and CSS custom properties.

See [FieldLabel](docs/field-label.md) for its presentation-only field-label
contract, required and optional marker policy, hint association and styling
hooks.

See [FormActions](docs/form-actions.md) for its flex layout contract, wrapping
behavior, ownership boundaries and gap customization.

See [Panel](docs/panel.md) for its semantic section contract, heading behavior,
responsibility boundaries, examples and CSS custom properties.

See [Surface](docs/surface.md) for its neutral container contract, semantic
boundaries, composition examples and CSS custom properties.

See [RelationshipGraph](docs/relationship-graph.md) for its data contract,
deterministic layout, interactions, callback payloads, resilience policy, and
CSS customization hooks.

## FieldLabel

Import `FieldLabel` only from the Studio entry point:

```svelte
<script lang="ts">
	import { FieldLabel } from 'giadaware-ui-components/studio';
</script>

<label for="display-name">
	<FieldLabel
		label="Display name"
		required
		requiredLabel="Required"
		hint="Shown on your public profile."
		hintId="display-name-hint"
	/>
</label>

<input
	id="display-name"
	name="displayName"
	required
	aria-describedby="display-name-hint"
/>
```

`FieldLabel` renders presentation only. Consumers provide translated strings,
the semantic `label` association, native `required`, stable control IDs and
hint relationships. Required presentation takes precedence over optional
presentation, and unresolved marker labels are omitted.

## Panel

Import `Panel` only from the Studio entry point:

```svelte
<script lang="ts">
	import { Panel } from 'giadaware-ui-components/studio';
</script>

<Panel title="Publishing settings" headingLevel={3}>
	<p>Configure how the current document is published.</p>
</Panel>
```

`Panel` renders one named semantic section with a visible heading and required
body content. Description and action snippets are optional and consumer-owned.
It does not manage forms, events, asynchronous state, live regions or workflow.
Use `AsyncOperationPanel` for operation lifecycle presentation. Use `Surface`
for neutral visual containment without a heading or section landmark.

## Surface

Import `Surface` only from the Studio entry point:

```svelte
<script lang="ts">
	import { Surface } from 'giadaware-ui-components/studio';
</script>

<nav aria-label="Resources">
	<Surface>
		<a href="/documentation">Documentation</a>
	</Surface>
</nav>
```

`Surface` renders required consumer content inside one neutral native `div`.
It adds no heading, role, landmark, accessible name, interaction, event or
application behavior. Consumers own any surrounding `nav`, `section`, `article`
or form semantics.

Consumer classes and inline styles compose with its scoped presentation through
the documented `--giu-surface-*` custom properties. Use `Panel` instead when
the content is a named section requiring a visible heading.

## PageIntro

Import `PageIntro` only from the Studio entry point:

```svelte
<script lang="ts">
	import { PageIntro } from 'giadaware-ui-components/studio';
</script>

<PageIntro>Manage the current document.</PageIntro>

<PageIntro>
	Manage the current document and
	<a href="/preview">open its preview</a>.
</PageIntro>
```

`PageIntro` always renders a semantic paragraph. Its required snippet may contain
plain or mixed inline content. Translations, links and page placement remain
consumer-owned. Consumer classes and inline styles compose with the scoped
component styles and documented `--giu-page-intro-*` hooks. It is not a
heading, alert, live region or landmark.

## Button

Import `Button` only from the Studio entry point:

```svelte
<script lang="ts">
	import { Button } from 'giadaware-ui-components/studio';
</script>

<Button>Save changes</Button>
<Button type="submit">Submit form</Button>
<Button disabled>Unavailable</Button>
<Button variant="danger">Remove item</Button>
<Button variant="secondary" size="compact">Move up</Button>
```

The variants are `primary`, `secondary`, and `danger`; sizes are `default` and
`compact`. `type` safely defaults to `button`. Applicable native button,
form, ARIA, data, and event attributes are forwarded. Consumer content must
provide the accessible name. Consumer classes and inline styles compose with
the scoped component styles, including the documented `--giu-button-*` hooks.

`Button` does not own pending, loading, result, or live-region behavior; use
`AsyncOperationPanel` for asynchronous lifecycle presentation. Links and
icon-only controls remain separate future components. Compose related
consumer-owned controls with `FormActions`.

## FormActions

Import `FormActions` only from the Studio entry point:

```svelte
<script lang="ts">
	import { Button, FormActions } from 'giadaware-ui-components/studio';
</script>

<FormActions align="end">
	<Button type="submit">Save changes</Button>
	<Button variant="secondary">Cancel</Button>
</FormActions>
```

`align` controls main-axis alignment and accepts `start`, `center`, `end`, or
`space-between`; it defaults to `start`. Wrapping defaults to `true`.
`space-between` operates independently on each wrapped flex line. Setting
`wrap={false}` may allow content to overflow and is an explicit consumer
choice.

The component renders its required snippet directly inside one native `div`.
Child semantics, accessible names, attributes, handlers, focus, keyboard,
submission, and navigation behavior remain consumer-owned. Margins and page
placement also remain consumer-owned. Consumer classes and styles compose with
the component, whose only public CSS custom property is
`--giu-form-actions-gap` with a `0.75rem` fallback.

Keep the primary action first in DOM order unless the consuming workflow has a
documented reason to choose a different order. `FormActions` is not a toolbar:
interfaces that require toolbar semantics or arrow-key navigation need a
separate component.

## SocialIcon

The root entry point exports:

```ts
import {
	SOCIAL_ICON_IDS,
	SocialIcon
} from 'giadaware-ui-components';

import type {
	SocialIconId
} from 'giadaware-ui-components';
```

The closed identifier registry is:

- `instagram`;
- `facebook`;
- `x`;
- `github`;
- `github-sponsors`.

`github` renders the GitHub brand mark. `github-sponsors` renders the filled
heart used for GitHub Sponsors links. Unknown runtime identifiers render
nothing; development builds emit one warning for each invalid condition.

Decorative use is the default:

```svelte
<a href="/profile" aria-label="Profilo GitHub">
	<SocialIcon id="github" />
</a>
```

Informative use requires a non-empty accessible label:

```svelte
<SocialIcon
	id="github"
	decorative={false}
	ariaLabel="Profilo GitHub"
	title="GitHub"
/>
```

Sizing defaults to `24px`. A numeric `size`, `width` or `height` becomes a CSS
pixel value; strings are passed as CSS lengths. `width` and `height` override
the corresponding axis set by `size`.

The SVG uses:

```text
viewBox="0 0 24 24"
fill="currentColor"
```

Color therefore inherits from the surrounding CSS context.

### Tree-shaking contract

`SocialIcon` selects its glyph dynamically from an identifier. Importing the
component therefore legitimately includes all five approved geometries.

The root export graph nevertheless keeps the public registry independent from
the component implementation. The current gate demonstrates that importing
only `SOCIAL_ICON_IDS` excludes `SocialIcon`, its runtime helpers and all five
SVG geometries in the clean packed consumer compiled by the Vite SSR test. It
does not claim a universal guarantee for every bundler.

### Third-party geometry

Brand geometries come from Simple Icons 16.26.0. The source package license is
CC0-1.0, but the Simple Icons disclaimer states that the project license does
not imply every individual icon is CC0. Trademark and individual icon terms
may still apply, and CC0 does not grant trademark rights.

The GitHub Sponsors heart comes from GitHub Primer Octicons v19.29.2,
`icons/heart-fill-24.svg`, under the MIT License, Copyright (c) 2026 GitHub
Inc.

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the complete notices.

## FormStatus

The root entry point exports:

```ts
import { FormStatus } from 'giadaware-ui-components';

import type { FormStatusTone } from 'giadaware-ui-components';
```

`FormStatusTone` is the closed union `success | error | warning | info`.
`message` is required and is rendered without package-provided labels or other
localized text. An empty message renders no status. `tone` defaults to `info`.

Statuses are persistent by default:

```svelte
<FormStatus
	message="Impostazioni salvate"
	tone="success"
/>
```

Set `durationMs` to a positive finite number to dismiss the message
automatically in the browser:

```svelte
<FormStatus
	message="Bozza aggiornata"
	tone="info"
	durationMs={5000}
/>
```

The default `null`, as well as zero, negative values, `NaN` and infinities,
remain persistent. Changing `message` or `durationMs` makes the current message
visible again and restarts the timing lifecycle. Durations beyond the browser's
single-timer limit are scheduled in bounded consecutive chunks rather than
overflowing. Timers are not created during server rendering and are cleaned up
when props change or the component is destroyed.

The accessibility policy is deterministic: `error` uses `role="alert"` with
`aria-live="assertive"`; `success`, `warning` and `info` use `role="status"`
with `aria-live="polite"`. Every rendered status uses `aria-atomic="true"`.
There is no close button, animation, dismissal callback or toast manager.

The component accepts `class` and `style` on its root element. Its scoped CSS
uses only these public neutral custom properties, each with a readable fallback:

- layout: `--giu-form-status-padding`, `--giu-form-status-border-width`,
  `--giu-form-status-border-radius`, `--giu-form-status-line-height`;
- per-tone colors: `--giu-form-status-<tone>-border`,
  `--giu-form-status-<tone>-background` and
  `--giu-form-status-<tone>-color`.

## ImageAttachmentControl

Import the component and its consumer-facing types from the Studio entry point:

```ts
import { ImageAttachmentControl } from 'giadaware-ui-components/studio';
import type {
	ImageAttachmentControlLabels,
	ImageAttachmentState
} from 'giadaware-ui-components/studio';
```

`ImageAttachmentControl` is controlled through `value` and `onvaluechange`.
Its final intent is `keep`, `replace` (with a native `File`) or `remove`.
`currentImage` describes an existing image when one is available. Callers own
all labels and validation messages, and can configure `accept`, `maxSizeBytes`,
a custom `validator` and `disabled`.

```svelte
<script lang="ts">
	import { ImageAttachmentControl } from 'giadaware-ui-components/studio';
	import type {
		ImageAttachmentControlLabels,
		ImageAttachmentState
	} from 'giadaware-ui-components/studio';

	let value: ImageAttachmentState = $state({ intent: 'keep', file: null });

	const labels: ImageAttachmentControlLabels = {
		input: 'Choose image',
		cancelReplacement: 'Cancel replacement',
		remove: 'Remove image',
		cancelRemoval: 'Cancel removal',
		keepExistingStatus: 'Existing image kept',
		keepEmptyStatus: 'No image selected',
		replaceStatus: 'Replacement selected',
		removeStatus: 'Image will be removed',
		replacementPreviewAlt: 'Replacement preview'
	};

	function save(state: ImageAttachmentState): void {
		switch (state.intent) {
			case 'keep':
				return;
			case 'replace':
				console.log('Selected file', state.file.name);
				return;
			case 'remove':
				console.log('Removal selected');
				return;
			default: {
				const exhaustive: never = state;
				return exhaustive;
			}
		}
	}
</script>

<ImageAttachmentControl
	{value}
	onvaluechange={(next) => value = next}
	currentImage={{ src: '/current-image.jpg', alt: 'Current image' }}
	invalidTypeMessage="Choose a supported image type"
	tooLargeMessage="Choose a smaller image"
	{labels}
	accept="image/png,image/jpeg"
	maxSizeBytes={5_000_000}
/>

<button type="button" onclick={() => save(value)}>Save</button>
```

The caller is responsible for interpreting and persisting the final intent.
The component provides no hidden removal field and no built-in persistence.

## Requirements

Node.js:

    ^20.19.0 || >=22.12.0

The repository currently uses Node 24 in CI.

## Trial test harness

The private extraction trial uses a blocking test harness covering:

- deterministic server-side rendering;
- Chromium component rendering;
- client hydration without mismatch;
- automatic accessibility checks with Axe;
- isolated root, visitor and Studio dependency graphs;
- explicit opt-in CSS entry points;
- clean installation from the generated tarball;
- TypeScript and runtime imports from the packed artifact;
- one compatible Svelte runtime in the consumer;
- registry-publication refusal.

Install the Chromium test browser once on a development machine:

    npx playwright install chromium

## Local validation

Install dependencies:

    npm install

Run all current validation gates:

    npm run validate

Create a local trial artifact:

    npm pack

Registry publication is forbidden during private incubation.

Architecture and trial ownership are tracked in
https://github.com/gcomneno/atelier-kit/issues/127
